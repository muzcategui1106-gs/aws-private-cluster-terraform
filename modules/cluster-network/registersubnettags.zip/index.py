import json
import boto3
def handler(event, context):
  ec2_client = boto3.client('ec2')
  if event['RequestType'] == 'Delete':
    for subnet_id in event['ResourceProperties']['Subnets']:
      ec2_client.delete_tags(Resources=[subnet_id], Tags=[{'Key': 'kubernetes.io/cluster/' + event['ResourceProperties']['InfrastructureName']}]);
  elif event['RequestType'] == 'Create':
    for subnet_id in event['ResourceProperties']['Subnets']:
      ec2_client.create_tags(Resources=[subnet_id], Tags=[{'Key': 'kubernetes.io/cluster/' + event['ResourceProperties']['InfrastructureName'], 'Value': 'shared'}]);
